
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ServerGuardianPro — لوحة تقرير HTML
- متوافق مع Python 3.9
- يقرأ ملفات JSON بأمان ويدعم UTF-8
- يستخدم matplotlib (Agg) لتوليد رسوم PNG
"""
import json, argparse, os
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

def safe_load_json(path):
    if not os.path.isfile(path) or os.stat(path).st_size == 0:
        return {}
    for enc in ("utf-8", "utf-8-sig"):
        try:
            txt = open(path, "r", encoding=enc).read().replace(" ", "")
            return json.loads(txt)
        except Exception:
            pass
    return {}

def bar_memory(m, out_dir):
    mem_total_kb = int((m.get('system') or {}).get('mem_total_kb', 0) or 0)
    mem_avail_kb = int((m.get('system') or {}).get('mem_available_kb', 0) or 0)
    mem_total = mem_total_kb / 1024.0
    mem_avail = mem_avail_kb / 1024.0
    used = max(mem_total - mem_avail, 0)
    plt.figure(figsize=(6, 4))
    plt.title('استخدام الذاكرة (MB)')
    plt.bar(['Used', 'Free'], [used, mem_avail], color=['#e74c3c', '#2ecc71'])
    mem_png = os.path.join(out_dir, 'mem.png')
    plt.tight_layout(); plt.savefig(mem_png); plt.close()
    return mem_png

def barh_slowest(l, out_dir):
    slow = (l.get('top_slowest') or [])[:20]
    labels = [(s.get('endpoint', '') or '')[:60] for s in slow]
    vals = [float(s.get('p95', 0) or 0) for s in slow]
    plt.figure(figsize=(10, 6))
    plt.title('أبطأ المسارات (p95)')
    plt.barh(labels, vals, color='#f39c12'); plt.xlabel('ثواني')
    plt.gca().invert_yaxis()
    slow_png = os.path.join(out_dir, 'slow.png')
    plt.tight_layout(); plt.savefig(slow_png); plt.close()
    return slow_png

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--metrics', required=True)
    p.add_argument('--logs', required=True)
    p.add_argument('--db', required=True)
    p.add_argument('--actions', required=True)
    p.add_argument('--out', required=True)
    a = p.parse_args()

    M = safe_load_json(a.metrics)
    L = safe_load_json(a.logs)
    D = safe_load_json(a.db)
    A = safe_load_json(a.actions)

    out_dir = os.path.dirname(a.out) or "."
    os.makedirs(out_dir, exist_ok=True)

    mem_png = bar_memory(M, out_dir)
    slow_png = barh_slowest(L, out_dir)

    parts = []
    parts.append('<html><head><meta charset="utf-8"><title>ServerGuardianPro — لوحة المراقبة</title>')
    parts.append('<style>body{font-family:Arial;background:#f7f9fb;color:#333} h1{color:#0a66c2} table{border-collapse:collapse;width:100%} th,td{border:1px solid #ccc;padding:6px} th{background:#eaf2fb} .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}</style>')
    parts.append('</head><body>')
    parts.append('<h1>لوحة مراقبة ServerGuardianPro</h1>')
    parts.append('<div class="grid">')
    parts.append(f'<div><h2>استخدام الذاكرة</h2><img src="{os.path.basename(mem_png)}" /></div>')
    parts.append(f'<div><h2>أبطأ المسارات (p95)</h2><img src="{os.path.basename(slow_png)}" /></div>')
    parts.append('</div>')
    parts.append('<h2>توصيات</h2><ul>')
    for n in (A.get('notes') or []): parts.append(f'<li>{n}</li>')
    for adv in (A.get('advice') or []): parts.append(f'<li>{adv}</li>')
    parts.append('</ul>')
    parts.append('<h2>مقاييس InnoDB</h2><pre>')
    parts.append(json.dumps((D.get('metrics') or {}), ensure_ascii=False, indent=2))
    parts.append('</pre>')
    parts.append('</body></html>')

    html = "
".join(parts)
    with open(a.out, 'w', encoding='utf-8') as f:
        f.write(html)

if __name__ == '__main__':
    main()
