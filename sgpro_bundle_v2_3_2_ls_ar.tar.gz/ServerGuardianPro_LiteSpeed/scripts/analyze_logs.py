
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import re, json, argparse, os, statistics, yaml

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--config', required=True)
    p.add_argument('--out', required=True)
    a = p.parse_args()

    cfg = yaml.safe_load(open(a.config,'r',encoding='utf-8'))
    max_lines = int(cfg.get('logs',{}).get('max_lines',500000))
    acc = (cfg.get('web',{}).get('litespeed',{}) or {}).get('access_log','/usr/local/lsws/logs/access.log')

    re_ls = re.compile(r'"(?P<m>[A-Z]+) (?P<p>[^\s]+) [^"]+" (?P<s>\d{3}) (?P<b>\d+)')

    E={}; T=0
    if os.path.exists(acc):
        for i,line in enumerate(open(acc,'r',encoding='utf-8',errors='ignore')):
            if i>=max_lines: break
            m=re_ls.search(line)
            if not m: continue
            ep=m.group('p').split('?')[0]
            d=E.setdefault(ep,{ 'times':[], 'status':{}, 'bytes':0, 'count':0 })
            d['times'].append(0.0)
            st=int(m.group('s')); d['status'][st]=d['status'].get(st,0)+1
            d['bytes']+=int(m.group('b')); d['count']+=1; T+=1
    res={'endpoints':{}, 'summary':{'total_requests':T}}
    for k,d in E.items():
        t=d['times']; avg=(sum(t)/len(t)) if t else 0.0
        p50=statistics.median(t) if t else 0.0
        p95=statistics.quantiles(t,n=100)[94] if len(t)>=20 else (max(t) if t else 0.0)
        p99=statistics.quantiles(t,n=100)[98] if len(t)>=50 else (max(t) if t else 0.0)
        res['endpoints'][k]={'count':d['count'],'avg':round(avg,4),'p50':round(p50,4),
                             'p95':round(p95,4),'p99':round(p99,4),'bytes_total':d['bytes'],
                             'status_dist':d['status']}
    slow=sorted(res['endpoints'].items(), key=lambda kv: kv[1]['p95'], reverse=True)[:30]
    res['top_slowest']=[{'endpoint':k, **v} for k,v in slow]
    json.dump(res, open(a.out,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
    print('Wrote logs analysis to', a.out)

if __name__=='__main__':
    main()
