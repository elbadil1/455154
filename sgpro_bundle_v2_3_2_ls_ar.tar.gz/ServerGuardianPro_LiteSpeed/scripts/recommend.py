
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, argparse, yaml, os

def load_json(p):
    if not os.path.isfile(p) or os.stat(p).st_size==0: return {}
    for enc in ('utf-8','utf-8-sig'):
        try: return json.load(open(p,'r',encoding=enc))
        except Exception: pass
    return {}

p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--metrics',required=True); p.add_argument('--logs',required=True); p.add_argument('--db',required=True); p.add_argument('--out',required=True); a=p.parse_args()
cfg=yaml.safe_load(open(a.config,'r',encoding='utf-8'))
M=load_json(a.metrics); L=load_json(a.logs); D=load_json(a.db)
A={'notes':[], 'changes':[], 'advice':[]}
mem_total_mb=int((M.get('system') or {}).get('mem_total_kb',0))//1024
mem_avail_mb=int((M.get('system') or {}).get('mem_available_kb',0))//1024
php=M.get('php') or {}
if php:
  ml=str(php.get('memory_limit','') or '')
  if ml.endswith('M'):
    try:
      cur=int(ml[:-1])
      if cur<256 and mem_total_mb>2048:
        A['changes'].append({'target':'php.ini','file':(cfg.get('php') or {}).get('ini_path'),
                             'key':'memory_limit','current':ml,'recommended':'512M',
                             'rationale':'رفع حد الذاكرة لموقع نشِط.'})
    except: pass
  if str(php.get('opcache_enable','0')) in ('0','false','False',''):
    A['advice'].append('يوصى بتمكين OPcache (opcache.enable=1).')
slow=(L.get('top_slowest') or [])[:20]
if slow:
  A['notes'].append('أبطأ 20 مسار (p95):')
  for it in slow: A['notes'].append(f"{it.get('endpoint','')} :: p95={it.get('p95',0)}s, count={it.get('count',0)}")
if mem_avail_mb<2048:
  A['advice'].append('الذاكرة المتاحة منخفضة (<2GB). راجع العمليات أو زد الموارد.')
json.dump(A,open(a.out,'w',encoding='utf-8'),ensure_ascii=False,indent=2)
print('Wrote recommendations to',a.out)
