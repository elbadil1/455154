
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, argparse, os, sys

def load_metrics(path):
    if not os.path.isfile(path) or os.stat(path).st_size == 0:
        print(f"[ERR] Metrics file missing or empty: {path}", file=sys.stderr)
        return {"system": {}, "php": {}, "mysql": {}}
    for enc in ("utf-8","utf-8-sig"):
        try:
            with open(path,"r",encoding=enc) as f:
                txt=f.read().replace(" ","")
            return json.loads(txt)
        except Exception as e:
            last=e
    print(f"[ERR] Cannot parse JSON: {last}", file=sys.stderr)
    return {"system": {}, "php": {}, "mysql": {}}

p=argparse.ArgumentParser(); p.add_argument('--metrics',required=True); p.add_argument('--out',required=True); a=p.parse_args()
M=load_metrics(a.metrics)
mysql=M.get('mysql') or {}
V={}; S={}
if mysql:
  for line in (mysql.get('variables') or '').split(';'):
    if ':' in line:
      k,v=line.split(':',1); V[k.strip()]=v.strip()
  for line in (mysql.get('status') or '').split(';'):
    if ':' in line:
      k,v=line.split(':',1); S[k.strip()]=v.strip()
mem_total_kb=int((M.get('system') or {}).get('mem_total_kb',0) or 0)
mem_total_mb=mem_total_kb//1024
bp_size=int(V.get('innodb_buffer_pool_size',0) or 0)
reads=float(S.get('Innodb_buffer_pool_reads',0) or 0)
req=float(S.get('Innodb_buffer_pool_read_requests',0) or 0)
hit=(1.0-(reads/req)) if req>0 else None
io_cap=int(V.get('innodb_io_capacity',200) or 200)
flush_at=int(V.get('innodb_flush_log_at_trx_commit',1) or 1)
log_file_size=int(V.get('innodb_log_file_size',0) or 0)
log_files_in_group=int(V.get('innodb_log_files_in_group',2) or 2)
redo_total=log_file_size*log_files_in_group
max_conn=int(V.get('max_connections',151) or 151)
threads=int(S.get('Threads_connected',0) or 0)
qps=None
try:
  qps=float(S.get('Queries',0) or 0)/float(S.get('Uptime',1) or 1)
except: qps=None
res={'summary':{},'advice':[],'metrics':{}}
res['metrics']={'mem_total_mb':mem_total_mb,'innodb_buffer_pool_size_bytes':bp_size,'buffer_pool_hit':hit,'innodb_io_capacity':io_cap,'innodb_flush_log_at_trx_commit':flush_at,'redo_total_bytes':redo_total,'max_connections':max_conn,'threads_connected':threads,'qps':qps}
if mem_total_mb>0 and bp_size>0:
  bp_mb=bp_size//(1024*1024)
  target=int(mem_total_mb*0.6) if mem_total_mb>8192 else int(mem_total_mb*0.5)
  if bp_mb < target:
    res['advice'].append(f"رفع innodb_buffer_pool_size إلى ~{target}MB (حاليًا {bp_mb}MB)")
if hit is not None and hit < 0.99:
  res['advice'].append(f"Buffer Pool Hit Ratio منخفض (~{hit:.3f}). زيادة buffer pool أو تحسين الاستعلامات.")
if flush_at==1 and (qps or 0)<300:
  res['advice'].append("يمكن ضبط innodb_flush_log_at_trx_commit=2 لتقليل الكتابة على القرص إن سمح عبء الاتساق.")
if redo_total and redo_total < 1024*1024*1024:
  res['advice'].append("زيادة حجم سجل Redo إلى ~1GB+.")
if threads>int(max_conn*0.8):
  res['advice'].append("Threads_connected يقترب من max_connections؛ اضبط Pool التطبيق وتحقق من التسريبات.")
with open(a.out,'w',encoding='utf-8') as f:
  json.dump(res,f,ensure_ascii=False,indent=2)
print('Wrote deep DB analysis to',a.out)
