
#!/usr/bin/env bash
# Safe collector — avoids printf issues, compatible with AlmaLinux 9
set -euo pipefail
STAMP=$(date +"%Y-%m-%d_%H-%M-%S")
REPORT_DIR=${REPORT_DIR:-/opt/serverguardianpro/reports}
STATE_DIR=${STATE_DIR:-/opt/serverguardianpro/state}
mkdir -p "$REPORT_DIR" "$STATE_DIR"
OUT_JSON="$REPORT_DIR/sg_$STAMP.json"
LAST_JSON="$STATE_DIR/last.json"

mem_total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
mem_avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
swap_total=$(awk '/SwapTotal/{print $2}' /proc/meminfo)
swap_free=$(awk '/SwapFree/{print $2}' /proc/meminfo)
loadavg=$(awk '{print $1","$2","$3}' /proc/loadavg)
disk=$(df -hP | awk 'NR>1{print $1":"$2":"$3":"$4":"$5":"$6}' | paste -sd ';' -)
procs=$(ps -eo pid,comm,%cpu,%mem,rss,vsz --sort=-%cpu | head -n 40 | awk '{print $1","$2","$3","$4","$5","$6}' | paste -sd ';' -)
net=$(awk 'NR>2{gsub(/ +/," "); gsub(/:/,"",$1); print $1"::"$2":"$10":"$2}' /proc/net/dev | paste -sd ';' -)

php_bin=$(command -v php || true)
php_version=""; php_sapi=""; php_ini=""; php_mem=""; php_maxexec=""; php_postmax=""; php_upmax=""; php_op=""
if [[ -n "$php_bin" ]]; then
  php_version=$(php -r 'echo phpversion();' 2>/dev/null || true)
  php_sapi=$(php -r 'echo php_sapi_name();' 2>/dev/null || true)
  php_ini=$(php -r 'echo php_ini_loaded_file();' 2>/dev/null || true)
  php_mem=$(php -r 'echo ini_get("memory_limit");' 2>/dev/null || true)
  php_maxexec=$(php -r 'echo ini_get("max_execution_time");' 2>/dev/null || true)
  php_postmax=$(php -r 'echo ini_get("post_max_size");' 2>/dev/null || true)
  php_upmax=$(php -r 'echo ini_get("upload_max_filesize");' 2>/dev/null || true)
  php_op=$(php -r 'echo ini_get("opcache.enable");' 2>/dev/null || true)
fi

mysql_status=""; mysql_vars=""; mysql_innodb=""
if command -v mysql >/dev/null 2>&1; then
  host=${MYSQL_HOST:-127.0.0.1}; user=${MYSQL_USER:-root}; pass=${MYSQL_PASSWORD:-}; port=${MYSQL_PORT:-3306}
  mysql_status=$(mysql -h "$host" -P "$port" -u "$user" ${pass:+-p$pass} -e "SHOW GLOBAL STATUS" 2>/dev/null | sed 's/	/:/g' | paste -sd ';' - || true)
  mysql_vars=$(mysql   -h "$host" -P "$port" -u "$user" ${pass:+-p$pass} -e "SHOW VARIABLES"       2>/dev/null | sed 's/	/:/g' | paste -sd ';' - || true)
  mysql_innodb=$(mysql -h "$host" -P "$port" -u "$user" ${pass:+-p$pass} -e "SHOW ENGINE INNODB STATUS\G" 2>/dev/null | sed 's/	/ /g' | tr '
' ' ' || true)
fi

python3 - <<'PY'   "$loadavg" "$mem_total" "$mem_avail" "$swap_total" "$swap_free" "$disk" "$procs" "$net"   "$php_version" "$php_sapi" "$php_ini" "$php_mem" "$php_maxexec" "$php_postmax" "$php_upmax" "$php_op"   "$mysql_status" "$mysql_vars" "$mysql_innodb"   "$OUT_JSON" "$LAST_JSON"
import json, sys
(LOAD, MEM_T, MEM_A, SW_T, SW_F, DISK, PROCS, NET,
 PHP_V, PHP_SAPI, PHP_INI, PHP_MEM, PHP_MAXEXEC, PHP_POSTMAX, PHP_UPMAX, PHP_OP,
 MY_STATUS, MY_VARS, MY_INNODB,
 OUT_JSON, LAST_JSON) = sys.argv[1:]

data = {
  "system": {
    "loadavg": LOAD,
    "mem_total_kb": int(MEM_T or 0),
    "mem_available_kb": int(MEM_A or 0),
    "swap_total_kb": int(SW_T or 0),
    "swap_free_kb": int(SW_F or 0),
    "disk": DISK,
    "top_procs": PROCS,
    "net": NET
  },
  "php": {
    "version": PHP_V, "sapi": PHP_SAPI, "php_ini": PHP_INI,
    "memory_limit": PHP_MEM, "max_execution_time": PHP_MAXEXEC,
    "post_max_size": PHP_POSTMAX, "upload_max_filesize": PHP_UPMAX,
    "opcache_enable": PHP_OP
  },
  "mysql": {
    "status": MY_STATUS, "variables": MY_VARS, "innodb_status": MY_INNODB
  }
}
js = json.dumps(data, ensure_ascii=False)
open(OUT_JSON, 'w', encoding='utf-8').write(js)
open(LAST_JSON, 'w', encoding='utf-8').write(js)
print('Saved:', OUT_JSON)
print('Updated:', LAST_JSON)
PY
