
#!/usr/bin/env bash
# ServerGuardianPro — v2.3 All-in-One Installer (AlmaLinux 9 + cPanel Jupiter + Python 3.9)
set -euo pipefail

STACK="${STACK:-auto}"   # auto|nginx|litespeed
WORKDIR="${WORKDIR:-/opt/serverguardianpro}"
PATCH_NGINX_LOGFORMAT="${PATCH_NGINX_LOGFORMAT:-true}"

log(){ echo -e "[INFO] $*"; }
warn(){ echo -e "[WARN] $*"; }
error(){ echo -e "[ERROR] $*" >&2; exit 1; }

require_root(){ [[ $EUID -eq 0 ]] || error "Run as root"; }
require_py39(){ command -v python3 >/dev/null 2>&1 || error "python3 required"; PYV=$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])'); [[ "$PYV" =~ ^3\.9|3\.1[0-9]$ ]] || warn "Python $PYV — scripts target 3.9+, should still work"; }

choose_stack(){
  if [[ "$STACK" == "auto" ]]; then
    if [[ -d /usr/local/lsws ]]; then STACK="litespeed"; elif command -v nginx >/dev/null 2>&1; then STACK="nginx"; else error "Neither LiteSpeed nor NGINX/Engintron detected"; fi
  fi
  [[ "$STACK" == "nginx" || "$STACK" == "litespeed" ]] || error "STACK must be nginx|litespeed|auto"
}

install_common(){
  useradd -r -s /usr/sbin/nologin sgpro 2>/dev/null || true
  mkdir -p "$WORKDIR" "$WORKDIR/scripts" "$WORKDIR/dashboard" "$WORKDIR/state" "$WORKDIR/reports"
  chown -R sgpro:sgpro "$WORKDIR" || true
}

install_nginx(){
  log "Installing Engintron/NGINX variant"
  tar -xzf ./sgpro_bundle_v2_3_ng_ar.tar.gz -C "$WORKDIR"
  PKG="$WORKDIR/ServerGuardianPro_Engintron"
  cp -f "$PKG/config.sample.yaml" "$WORKDIR/config.yaml"
  cp -f "$PKG/scripts"/* "$WORKDIR/scripts/"; cp -f "$PKG/dashboard"/* "$WORKDIR/dashboard/"
  # cPanel plugin
  /usr/local/cpanel/scripts/install_plugin "$PKG/serverguardianpro_cpanel_ng_ar.tar.gz" --theme=jupiter || warn "install_plugin failed"
  # optional: patch nginx log_format to include $request_time
  if [[ "$PATCH_NGINX_LOGFORMAT" == "true" && -f /etc/nginx/nginx.conf ]]; then
    if ! grep -q 'request_time' /etc/nginx/nginx.conf ; then
      log "Patching nginx log_format to include $request_time"
      cp -a /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
      if ! grep -q 'log_format main' /etc/nginx/nginx.conf ; then
        cat >> /etc/nginx/nginx.conf <<'CONF'
log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                '$status $body_bytes_sent "$http_referer" "$http_user_agent" $request_time';
CONF
      else
        sed -i 's/log_format\s\+main\s\+\(.*\);/log_format main  $request_time;/' /etc/nginx/nginx.conf || true
      fi
      nginx -t && nginx -s reload || warn "nginx reload failed"
    fi
  fi
  # systemd
  cp -f "$WORKDIR/ops/systemd/sgpro-report.service" /etc/systemd/system/
  cp -f "$WORKDIR/ops/systemd/sgpro-report.timer"   /etc/systemd/system/
  systemctl daemon-reload; systemctl enable --now sgpro-report.timer || warn "timer enable failed"
}

install_litespeed(){
  log "Installing LiteSpeed variant"
  [[ -d /usr/local/lsws ]] || error "LiteSpeed not detected at /usr/local/lsws"
  tar -xzf ./sgpro_bundle_v2_3_ls_ar.tar.gz -C "$WORKDIR"
  PKG="$WORKDIR/ServerGuardianPro_LiteSpeed"
  cp -f "$PKG/config.sample.yaml" "$WORKDIR/config.yaml"
  cp -f "$PKG/scripts"/* "$WORKDIR/scripts/"; cp -f "$PKG/dashboard"/* "$WORKDIR/dashboard/"
  /usr/local/cpanel/scripts/install_plugin "$PKG/serverguardianpro_cpanel_ls_ar.tar.gz" --theme=jupiter || warn "install_plugin failed"
  cp -f "$WORKDIR/ops/systemd/sgpro-report.service" /etc/systemd/system/
  cp -f "$WORKDIR/ops/systemd/sgpro-report.timer"   /etc/systemd/system/
  systemctl daemon-reload; systemctl enable --now sgpro-report.timer || warn "timer enable failed"
}

first_cycle(){
  log "Running first cycle"
  bash "$WORKDIR/scripts/collect.sh"
  python3 "$WORKDIR/scripts/analyze_logs.py" --config "$WORKDIR/config.yaml" --out "$WORKDIR/state/logs.json" || true
  python3 "$WORKDIR/scripts/analyze_db.py"    --metrics "$WORKDIR/state/last.json" --out "$WORKDIR/state/db.json" || true
  python3 "$WORKDIR/scripts/recommend.py"     --config "$WORKDIR/config.yaml" --metrics "$WORKDIR/state/last.json" --logs "$WORKDIR/state/logs.json" --db "$WORKDIR/state/db.json" --out "$WORKDIR/state/actions.json" || true
  python3 "$WORKDIR/dashboard/build_report.py" --metrics "$WORKDIR/state/last.json" --logs "$WORKDIR/state/logs.json" --db "$WORKDIR/state/db.json" --actions "$WORKDIR/state/actions.json" --out "$WORKDIR/reports/dashboard.html" || true
  cp -f "$WORKDIR/reports/dashboard.html" /usr/local/cpanel/base/frontend/jupiter/serverguardianpro/dashboard.html || true
  /usr/local/cpanel/scripts/restartsrv cpsrvd --restart || true
  log "DONE — افتح cPanel ▸ حارس الخادم ▸ حارس الخادم — لوحة المراقبة"
}

usage(){ cat <<'HLP'
Usage:
  # بعد فك الضغط:
  STACK=nginx bash sgpro_master_v2_3.sh
  STACK=litespeed bash sgpro_master_v2_3.sh
  # أو دع المثبّت يختار تلقائيًا
  bash sgpro_master_v2_3.sh

Env:
  STACK=auto|nginx|litespeed
  PATCH_NGINX_LOGFORMAT=true|false
HLP
}

case "${1:-install}" in
  install) require_root; require_py39; choose_stack; install_common; [[ "$STACK" == "nginx" ]] && install_nginx || install_litespeed; first_cycle ;;
  help|-h|--help) usage ;;
  *) usage; exit 1 ;;
esac
